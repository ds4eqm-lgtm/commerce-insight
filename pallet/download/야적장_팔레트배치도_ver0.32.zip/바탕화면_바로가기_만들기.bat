@echo off
rem Pallet yard map: make a desktop shortcut on this PC
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0make_shortcut.ps1"
timeout /t 3 >nul
