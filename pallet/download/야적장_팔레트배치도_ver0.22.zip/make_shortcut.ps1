﻿# 야적장 팔레트 배치도: PC 바탕화면에 바로가기(앱 창) 만들기
# 크롬(없으면 엣지)을 주소창 없는 앱 창(--app)으로 여는 바로가기를 바탕화면에 만든다.
$ErrorActionPreference = 'Stop'
$url  = 'https://ds4eqm-lgtm.github.io/commerce-insight/pallet/'
$name = '야적장 팔레트 배치도'
$home2 = Join-Path $env:LOCALAPPDATA 'PalletYard'
New-Item -ItemType Directory -Force $home2 | Out-Null
$ico = Join-Path $home2 'pallet.ico'
Copy-Item (Join-Path $PSScriptRoot 'pallet.ico') $ico -Force

$browsers = @(
  (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
  (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
  (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'),
  (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
  (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe')
)
$exe = $browsers | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1

$desk = [Environment]::GetFolderPath('Desktop')
$lnk = Join-Path $desk ($name + '.lnk')
$sh = New-Object -ComObject WScript.Shell
$s = $sh.CreateShortcut($lnk)
if ($exe) {
  $s.TargetPath = $exe
  $s.Arguments = '--app=' + $url
  $s.WorkingDirectory = Split-Path $exe
} else {
  $s.TargetPath = $url
}
$s.IconLocation = $ico + ',0'
$s.Description = $name
$s.Save()
Write-Host ''
Write-Host "바탕화면에 '$name' 바로가기를 만들었습니다." -ForegroundColor Green
Start-Process -FilePath $lnk
