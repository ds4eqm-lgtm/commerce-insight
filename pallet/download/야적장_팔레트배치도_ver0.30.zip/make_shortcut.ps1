﻿# 야적장 팔레트 배치도: PC 바탕화면 바로가기 만들기 (ver 0.30: 바탕화면만, 팔레트 아이콘)
# 크롬/엣지에 앱으로 설치되어 있으면 그 앱으로, 아니면 주소창 없는 앱 창(--app)으로 여는 바로가기를 만든다.
$ErrorActionPreference = 'Stop'
$url   = 'https://ds4eqm-lgtm.github.io/commerce-insight/pallet/'
$appIds = @('kljdenbdodgfpmoekpoglcajfcnkomcl', 'ekhbchfikmcefgmdgbekdgjbjabjpflk')   # 크롬·엣지가 이 앱에 붙이는 번호 (0.25부터 / 0.19~0.24 설치분)
$name  = '야적장 팔레트 배치도'
$home2 = Join-Path $env:LOCALAPPDATA 'PalletYard'
New-Item -ItemType Directory -Force $home2 | Out-Null
# 윈도우가 예전 아이콘을 기억해 두지 않도록 버전마다 다른 이름으로 둔다
Get-ChildItem $home2 -Filter 'pallet*.ico' -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
$ico = Join-Path $home2 'pallet_030.ico'
Copy-Item (Join-Path $PSScriptRoot 'pallet.ico') $ico -Force

$cands = @(
  @{ exe = (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe');        data = (Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data') },
  @{ exe = (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'); data = (Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data') },
  @{ exe = (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe');        data = (Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data') },
  @{ exe = (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'); data = (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\User Data') },
  @{ exe = (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe');        data = (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\User Data') }
)
$launchArgs = '--app=' + $url
$exe = $null
foreach ($c in $cands) {
  if (-not ($c.exe -and (Test-Path $c.exe))) { continue }
  if (-not $exe) { $exe = $c.exe }
  # 이미 앱으로 설치된 프로필이 있으면 그 앱으로 연다
  $hit = $null
  foreach ($id in $appIds) {
    $prof = Get-ChildItem $c.data -Directory -ErrorAction SilentlyContinue | Where-Object { Test-Path (Join-Path $_.FullName ('Web Applications\_crx_' + $id)) } | Select-Object -First 1
    if ($prof) { $hit = @{ p = $prof.Name; id = $id }; break }
  }
  if ($hit) { $exe = $c.exe; $launchArgs = '--profile-directory="' + $hit.p + '" --app-id=' + $hit.id; break }
}

$sh = New-Object -ComObject WScript.Shell
function Make($folder) {
  New-Item -ItemType Directory -Force $folder | Out-Null
  $s = $sh.CreateShortcut((Join-Path $folder ($name + '.lnk')))
  if ($exe) { $s.TargetPath = $exe; $s.Arguments = $launchArgs; $s.WorkingDirectory = Split-Path $exe } else { $s.TargetPath = $url }
  $s.IconLocation = $ico + ',0'
  $s.Description = $name
  $s.Save()
}
$desk = [Environment]::GetFolderPath('Desktop')
Make $desk
# 0.25~0.28 이 시작 메뉴에 만든 것은 지운다 (폴더가 열리는 혼란 방지)
$old = Join-Path ([Environment]::GetFolderPath('Programs')) ($name + '.lnk')
if (Test-Path $old) { Remove-Item $old -Force -ErrorAction SilentlyContinue }
# 브라우저로 만든 크롬 모양 바로가기(.html/.url)는 지운다
foreach ($e in @('.html','.url')) { $f = Join-Path $desk ($name + $e); if (Test-Path $f) { Remove-Item $f -Force -ErrorAction SilentlyContinue } }
# 아이콘 새로 고침
try { & (Join-Path $env:SystemRoot 'System32\ie4uinit.exe') -show *> $null } catch {}
Write-Host ''
Write-Host "바탕화면에 '$name' 바로가기를 만들었습니다." -ForegroundColor Green
Start-Process -FilePath (Join-Path $desk ($name + '.lnk'))
